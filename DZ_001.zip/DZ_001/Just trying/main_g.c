#include <stdio.h>

int get_number_of_elements() {
  int n = 0;
  while (n <= 0 || n >= 10000) {
    printf("Введите число обьектов в массиве (от 1 до 10000): ");
    scanf("%d", &n);
  }
  return n;
}

void get_elements_A(int A[], int n) {
  for(int i = 0; i < n; ++i) {
      printf("Введите A[%d]: ", i);
      scanf("%d", &A[i]);
  }
}

void fill_elements_B(int A[], int B[], int n) {
  for (int i = 0; i < n-1; ++i) {
    B[i] = A[i] + A[i+1];
  }
}

int generate_input_n() {
  srand(time(0));
  int n = 1 + rand() % 30;
  return n;
}

void generate_A(int A[], int n) {
  for (size_t i = 0; i < n; i++) {
    A[i] = 1 + rand() % 1000;
  }
  return A;
}

void print_elements(int A[], int n) {
  for(int i = 0; i < n; ++i) {
    printf("%d ", A[i]);
  }
}

int get_type_of_input() {
  int t = 0;
  while (t <= 0 || t > 2) {
    printf("Введите число (1 или 2): ");
    scanf("%d", &t);
  }
  printf("\n");
  return t;
}

int main() {
  printf("Выберете тип ввода.\n-----------\n1) Вручную\n2) Автоматически\n");
  int type = get_type_of_input();
  int n = 0;
  if (type == 1) {
    n = get_number_of_elements();
  } else {
    n = generate_input_n();
  }
  int A[n];
  int B[n-1];
  if (type == 1) {
    get_elements_A(A, n);
  } else {
    generate_A(A, n);
  }
  printf("Ответ:\n");
  fill_elements_B(A, B, n);
  printf("A[%d] = ", n);
  print_elements(A, n);
  printf("\nB[%d] = ", n-1);
  print_elements(B, n-1);
  return 0;
}
