import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

public class FileMerge {
        private final String pathOfRootFolder;
        private final String pathOfResultFile;

        public FileMerge(String rootFolderPath, String resultFilePath) {
            this.pathOfRootFolder = rootFolderPath;
            this.pathOfResultFile = resultFilePath;
        }

        public boolean doMerge() {
            ArrayList<Path> files = takeSortedFiles();
            files = takeSortWithRools(files);
            if (files.size() == 0) {
                System.out.println("Произошла ошибка, обнаружены циклы или файлов нет!");
                return false;
            }
            System.out.println("Список файлов!");
            for (Path i: files) {
                System.out.println(i.getFileName());
            }
            Path resultFilePath = takeFileToWrite();
            mergeFilesContent(files, resultFilePath);
            return true;
        }

        private ArrayList<Path> takeSortWithRools(ArrayList<Path> files) {
            Graph graph = new Graph(files);
            if (!graph.doSort()) return new ArrayList<Path>();
            return graph.getFinalList();
        }

        private ArrayList<Path> takeSortedFiles() {
            ArrayList<Path> files = new ArrayList<>();
            try {
                Files.walk(Paths.get(pathOfRootFolder))
                        .filter(Files::isRegularFile)
                        .sorted()
                        .forEach(files::add);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return files;
        }


        private Path takeFileToWrite() {
            Path resultFilePath = Paths.get(pathOfResultFile);
            File resultFile = new File(pathOfResultFile);
            if (resultFile.isFile() && !resultFile.isDirectory()) {
                try {
                    Files.newBufferedWriter(resultFilePath, StandardOpenOption.TRUNCATE_EXISTING);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    Files.createFile(resultFilePath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return resultFilePath;
        }

        private void mergeFilesContent(ArrayList<Path> files, Path resultFilePath) {
            if (files != null && resultFilePath != null) {
                files.forEach(file -> {
                    ArrayList<String> lines = new ArrayList<>();
                    try {
                        lines.addAll(Files.readAllLines(file));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        Files.write(resultFilePath, lines, StandardOpenOption.APPEND);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
            } else {
                throw new IllegalArgumentException("Ошибка, присутсвует null!");
            }

        }
    }