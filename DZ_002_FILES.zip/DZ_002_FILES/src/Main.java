import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static java.nio.charset.Charset.defaultCharset;

public class Main {
    public static final String ROOT_FOLDER_PATH = "test";
    public static final String RESULT_FILE_PATH = "output/output.txt";

    public static void main(String[] args) {
        FileMerge merger = new FileMerge(ROOT_FOLDER_PATH, RESULT_FILE_PATH);
        if (!merger.doMerge()) {
            System.out.println("Произошла ошибка, завершение программы!");
        } else {
            System.out.println("Ответ в файле: " + RESULT_FILE_PATH);
        }
    }
}