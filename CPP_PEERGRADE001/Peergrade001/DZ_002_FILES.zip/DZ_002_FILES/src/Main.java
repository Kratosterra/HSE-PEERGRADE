public class Main {
    public static final String FOLDER_PATH = "test";
    public static final String ANSWER_FILE_PATH = "output/ans.txt";

    public static void main(String[] args) {
        Merge merger = new Merge(FOLDER_PATH, ANSWER_FILE_PATH);
        if (!merger.merge()) {
            System.out.println("Произошла ошибка, завершение программы!");
        } else {
            System.out.println("\nОтвет в файле: " + ANSWER_FILE_PATH);
        }
    }
}